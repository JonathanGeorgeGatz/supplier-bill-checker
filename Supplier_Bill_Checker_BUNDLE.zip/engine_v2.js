// The Supplier Bill Checker — SECOND BUILD (after prompt 2), kept verbatim for the episode.
// Prompt 2 fixed the matching and brought in the receiving log: item codes normalized, every
// line priced against the agreed list, quantities checked against deliveries, credits handled.
// What the independent checker later caught, still in here exactly as built:
//   * the receiving check compares each line against the MOST RECENT delivery only — twelve
//     wipers plus twelve wipers reads as twelve, and a fully-delivered line gets flagged;
//   * duplicates are detected by invoice NUMBER alone — the same bill resubmitted under a new
//     number sails through;
//   * money lives in floating point — totals come back wearing fifteen decimals;
//   * the printed Line Total column is ignored (recomputed), so a bill that lies about its own
//     arithmetic is accepted in silence.
(function (root) {
  "use strict";
  function rows(text) { return text.split(/\r?\n/).filter(l => l.trim()).map(l => l.split(",")); }
  function num(s) { const v = parseFloat(String(s || "").replace(/[$,]/g, "")); return isNaN(v) ? null : v; }
  function pd(s) {
    const m = /^\s*(\d{4})-(\d{2})-(\d{2})\s*$/.exec(s || "");
    if (!m) return null;
    return Date.UTC(+m[1], +m[2] - 1, +m[3]);
  }
  const norm = s => (s || "").toUpperCase().replace(/[\s-]+/g, "");
  const nsup = s => (s || "").trim().toLowerCase();

  function build(pricesCsv, receivedCsv, billsCsv, opts) {
    const period = (opts && opts.period) || "";
    const pm = /^(\d{4})-(\d{2})$/.exec(period);
    if (!pm) throw new Error("need a period");
    const p = rows(pricesCsv), rc = rows(receivedCsv), b = rows(billsCsv);
    const ph = p[0].map(x => x.trim().toLowerCase());
    const rh = rc[0].map(x => x.trim().toLowerCase());
    const bh = b[0].map(x => x.trim().toLowerCase());
    const pi = n => ph.indexOf(n), ri = n => rh.indexOf(n), bi = n => bh.indexOf(n);
    const agreed = {};
    for (let r = 1; r < p.length; r++) {
      const row = p[r];
      const key = nsup(row[pi("supplier")]) + "|" + norm(row[pi("item code")]);
      const price = num(row[pi("agreed price")]);
      if (price !== null) agreed[key] = price;
    }
    const deliveries = [];                                       // every delivery, kept separate
    for (let r = 1; r < rc.length; r++) {
      const row = rc[r];
      const t = pd(row[ri("date")]), qty = num(row[ri("qty")]);
      if (t === null || qty === null || qty <= 0) continue;      // silently skipped
      deliveries.push({ key: nsup(row[ri("supplier")]) + "|" + norm(row[ri("item code")]), t, qty });
    }
    const seenInvoices = new Set();
    const flags = [];
    let over = 0, credits = 0;
    for (let r = 1; r < b.length; r++) {
      const row = b[r];
      const inv = (row[bi("invoice")] || "").trim();
      const t = pd(row[bi("date")]);
      const qty = num(row[bi("qty")]), price = num(row[bi("unit price")]);
      if (t === null || qty === null || price === null) continue; // silently skipped
      const dstr = (row[bi("date")] || "").trim();
      if (!dstr.startsWith(period)) continue;                     // outside the month
      if (qty < 0) { credits += qty * price; continue; }          // credits handled (this one is fine)
      const lineKey = inv + "|" + r;                              // duplicates: by invoice NUMBER only
      if (seenInvoices.has(inv + "|" + norm(row[bi("item code")]) + "|" + qty + "|" + price)) continue;
      seenInvoices.add(inv + "|" + norm(row[bi("item code")]) + "|" + qty + "|" + price);
      const key = nsup(row[bi("supplier")]) + "|" + norm(row[bi("item code")]);
      const a = agreed[key];
      if (a === undefined) continue;                              // no agreed price, nothing to say
      if (price > a) {                                            // no tolerance: a dime is a felony
        over += (price - a) * qty;
        flags.push({ invoice: inv, item: row[bi("item code")], what: "price", amount: (price - a) * qty });
      }
      // receiving: compare against the MOST RECENT delivery on or before the line's date (the sin)
      let last = null;
      for (const d of deliveries) if (d.key === key && d.t <= t && (last === null || d.t >= last.t)) last = d;
      const have = last ? last.qty : 0;
      if (qty > have) {
        const phantom = (qty - have) * price;
        over += phantom;
        flags.push({ invoice: inv, item: row[bi("item code")], what: last ? "more billed than delivered" : "no delivery found", amount: phantom });
      }
    }
    return { flags, count: flags.length, over, credits,
      display: String(over),                                      // floating point, proudly
      verdict: "Overbilled this month: $" + over + " across " + flags.length + " findings." };
  }
  root.BC_V2 = { build };
})(typeof window !== "undefined" ? window : (typeof module !== "undefined" ? module.exports : this));
