// The Supplier Bill Checker — FIRST BUILD (prompt 1), kept verbatim for the episode.
// Its sins, exactly as the naive build made them:
//   * it reads the bills and the price list, never the receiving log — quantities are taken
//     on faith, and a line for goods that never arrived is invisible;
//   * prices are matched by the EXACT Description string — "BRAKE PAD SET CERAMIC" is not
//     "Brake pad set ceramic", so most of the drifted lines never meet their agreed price;
//   * its main check is whether the bill agrees WITH ITSELF (qty x price == printed total);
//   * no duplicate logic of any kind — the same bill under a new number is two fine bills;
//   * a credit memo's negative quantity is reported as an error, and a price DROP is
//     "a problem" just like a raise;
//   * dates mean nothing — a bill dated "last Tuesday" is processed happily.
(function (root) {
  "use strict";
  function rows(text) { return text.split(/\r?\n/).filter(l => l.trim()).map(l => l.split(",")); }
  function num(s) { const v = parseFloat(String(s || "").replace(/[$,]/g, "")); return isNaN(v) ? null : v; }

  function build(pricesCsv, billsCsv) {
    const p = rows(pricesCsv), b = rows(billsCsv);
    const ph = p[0].map(x => x.trim().toLowerCase());
    const bh = b[0].map(x => x.trim().toLowerCase());
    const pi = n => ph.indexOf(n), bi = n => bh.indexOf(n);
    const byDesc = {};
    for (let r = 1; r < p.length; r++) {
      const row = p[r];
      const desc = row[pi("description")];
      const price = num(row[pi("agreed price")]);
      if (desc && price !== null) byDesc[desc] = price;
    }
    const problems = [];
    let billed = 0, lines = 0;
    for (let r = 1; r < b.length; r++) {
      const row = b[r]; lines++;
      const qty = num(row[bi("qty")]), price = num(row[bi("unit price")]), printed = num(row[bi("line total")]);
      const desc = row[bi("description")];
      if (qty === null || price === null) continue;              // silently skipped
      billed += qty * price;
      if (qty < 0) {                                              // a credit memo is "an error"
        problems.push({ invoice: row[bi("invoice")], what: "negative quantity", amount: Math.abs(qty * price) });
        continue;
      }
      if (printed !== null && Math.abs(printed - qty * price) > 0.005)
        problems.push({ invoice: row[bi("invoice")], what: "doesn't add up", amount: Math.abs(printed - qty * price) });
      const agreed = byDesc[desc];                                // exact string or nothing
      if (agreed !== undefined && Math.abs(agreed - price) > 0.005)
        problems.push({ invoice: row[bi("invoice")], what: "price mismatch", amount: Math.abs(agreed - price) * qty });
    }
    const found = problems.reduce((s, x) => s + x.amount, 0);
    return { lines, problems, problemCount: problems.length,
      found: +found.toFixed(2), billed: +billed.toFixed(2),
      verdict: problems.length ? "Found " + problems.length + " problems worth $" + found.toFixed(2) : "All bills look fine." };
  }
  root.BC_V1 = { build };
})(typeof window !== "undefined" ? window : (typeof module !== "undefined" ? module.exports : this));
