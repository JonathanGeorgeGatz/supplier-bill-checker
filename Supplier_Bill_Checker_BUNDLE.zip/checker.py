#!/usr/bin/env python3
"""Independent second implementation of the Supplier Bill Checker's rules (shares no code with
the tool). Reads prices.csv + received.csv + bills.csv, prints a JSON report in the same shape
as engine.js's build(). All money in integer cents; divisions via half-up integers."""
import csv, datetime, io, json, re, sys

DEF = {"tolTenths": 5, "dupWindowDays": 30, "requireReceiving": True}
MONEY = re.compile(r"^\s*\$?\s*(-?)([0-9][0-9,]*)(?:\.([0-9]{1,2}))?\s*$")
QTY = re.compile(r"^\s*(-?)([0-9]{1,6})\s*$")
DATE = re.compile(r"^\s*(\d{4})-(\d{2})-(\d{2})\s*$")
PERIOD = re.compile(r"^\s*(\d{4})-(\d{2})\s*$")


def half_up_div(a, b):
    return (2 * a + b) // (2 * b)


def pct_tenths(delta, base):
    s = -1 if delta < 0 else 1
    return s * half_up_div(abs(delta) * 1000, base)


def cents(s):
    m = MONEY.match(s or "")
    if not m:
        return None
    frac = m.group(3) or ""
    f = int(frac) * 10 if len(frac) == 1 else (int(frac) if frac else 0)
    v = int(m.group(2).replace(",", "")) * 100 + f
    return -v if m.group(1) == "-" else v


def int_qty(s):
    m = QTY.match(s or "")
    if not m:
        return None
    v = int(m.group(2))
    return -v if m.group(1) == "-" else v


def pdate(s):
    m = DATE.match(s or "")
    if not m:
        return None
    try:
        return datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    except ValueError:
        return None


def norm_item(s):
    return re.sub(r"[\s-]+", "", (s or "").upper())


def norm_sup(s):
    return (s or "").strip().lower()


def fmt_money(c):
    return ("-$" if c < 0 else "$") + format(abs(c) / 100, ",.2f")


def rows_of(text):
    return [r for r in csv.reader(io.StringIO(text)) if len(r) > 1 or (r and r[0].strip())]


def build(prices_csv, received_csv, bills_csv, settings=None):
    S = dict(DEF)
    S.update(settings or {})
    pm = PERIOD.match(str(S.get("period") or ""))
    if not pm or not (1 <= int(pm.group(2)) <= 12):
        raise ValueError("The Bill Checker never reads the clock — type the billing period (YYYY-MM).")
    py, pmo = int(pm.group(1)), int(pm.group(2))
    period_end = (datetime.date(py + 1, 1, 1) if pmo == 12 else datetime.date(py, pmo + 1, 1)) - datetime.timedelta(days=1)

    pr, rr, br = rows_of(prices_csv), rows_of(received_csv), rows_of(bills_csv)
    ph = [c.strip().lower() for c in pr[0]]
    rh = [c.strip().lower() for c in rr[0]]
    bh = [c.strip().lower() for c in br[0]]
    pi = {n: ph.index(n) for n in ph}
    ri = {n: rh.index(n) for n in rh}
    bi = {n: bh.index(n) for n in bh}

    refused_prices, refused_receipts, refused_bills = [], [], []
    prices, sup_names = {}, {}
    price_rows = 0
    for ln, row in enumerate(pr[1:], start=2):
        price_rows += 1
        g = lambda n: (row[pi[n]] if n in pi and pi[n] < len(row) else "").strip()
        sup, item = g("supplier"), g("item code")
        if not sup or not item:
            refused_prices.append({"line": ln, "name": sup or "(blank)", "reason": "supplier or item code missing"}); continue
        agreed = cents(g("agreed price"))
        if agreed is None or agreed < 0:
            refused_prices.append({"line": ln, "name": sup, "reason": "agreed price unreadable"}); continue
        key = norm_sup(sup) + "|" + norm_item(item)
        if key in prices:
            refused_prices.append({"line": ln, "name": sup, "reason": "duplicate item — the first row was kept"}); continue
        sup_names.setdefault(norm_sup(sup), sup)
        prices[key] = {"supplier": sup, "item": item, "agreedC": agreed, "line": ln}

    receipts, unmatched = [], []
    receipt_rows = 0
    for ln, row in enumerate(rr[1:], start=2):
        receipt_rows += 1
        g = lambda n: (row[ri[n]] if n in ri and ri[n] < len(row) else "").strip()
        d = pdate(g("date"))
        sup, item = g("supplier"), g("item code")
        qty = int_qty(g("qty"))
        if d is None:
            refused_receipts.append({"line": ln, "name": sup or "(blank)", "reason": "date unreadable"}); continue
        if qty is None or qty <= 0:
            refused_receipts.append({"line": ln, "name": sup, "reason": "quantity unreadable"}); continue
        key = norm_sup(sup) + "|" + norm_item(item)
        if key not in prices:
            unmatched.append({"line": ln, "supplier": sup, "item": item, "qty": qty, "date": g("date"), "ref": g("reference")}); continue
        receipts.append({"line": ln, "key": key, "qty": qty, "d": d})

    bills = []
    bill_lines = 0
    for ln, row in enumerate(br[1:], start=2):
        bill_lines += 1
        g = lambda n: (row[bi[n]] if n in bi and bi[n] < len(row) else "").strip()
        inv, sup, item, desc = g("invoice"), g("supplier"), g("item code"), g("description")
        if not inv:
            refused_bills.append({"line": ln, "name": sup or "(blank)", "reason": "no invoice number"}); continue
        d = pdate(g("date"))
        if d is None:
            refused_bills.append({"line": ln, "name": sup, "reason": "date unreadable"}); continue
        qty = int_qty(g("qty"))
        if qty is None or qty == 0:
            refused_bills.append({"line": ln, "name": sup, "reason": "quantity unreadable"}); continue
        unit = cents(g("unit price"))
        if unit is None or unit < 0:
            refused_bills.append({"line": ln, "name": sup, "reason": "unit price unreadable"}); continue
        printed = g("line total")
        amount = qty * unit
        if printed != "":
            pc = cents(printed)
            if pc is None or pc != amount:
                refused_bills.append({"line": ln, "name": sup, "reason": "arithmetic"}); continue
        bills.append({"line": ln, "inv": inv, "sup": sup, "supKey": norm_sup(sup), "item": item,
                      "itemKey": norm_item(item), "qty": qty, "unitC": unit, "amountC": amount,
                      "d": d, "date": g("date")})

    balance, received_total = {}, {}
    for rc in receipts:
        if rc["d"] > period_end:
            continue
        balance[rc["key"]] = balance.get(rc["key"], 0) + rc["qty"]
        received_total[rc["key"]] = received_total.get(rc["key"], 0) + rc["qty"]

    ordered = sorted(bills, key=lambda L: (L["d"], L["line"]))
    credits, outside, review, candidates = [], [], [], []
    for L in ordered:
        if L["qty"] < 0:
            credits.append(L); continue
        if not (L["d"].year == py and L["d"].month == pmo):
            outside.append(L); continue
        key = L["supKey"] + "|" + L["itemKey"]
        if key not in prices:
            review.append(L); continue
        candidates.append(L)

    inv_map = {}
    for L in candidates:
        ik = L["supKey"] + "|" + L["inv"]
        gte = inv_map.setdefault(ik, {"supKey": L["supKey"], "inv": L["inv"], "lines": [],
                                      "minD": L["d"], "firstLine": L["line"]})
        gte["lines"].append(L)
        if L["d"] < gte["minD"]:
            gte["minD"] = L["d"]
        if L["line"] < gte["firstLine"]:
            gte["firstLine"] = L["line"]
    invoices = sorted(inv_map.values(), key=lambda g2: (g2["minD"], g2["firstLine"]))
    seen, dup_invoices = [], []
    for g2 in invoices:
        g2["fp"] = ";".join(sorted(f'{L["itemKey"]}*{L["qty"]}*{L["unitC"]}' for L in g2["lines"]))
        dup_of = None
        for e in seen:
            if (e["supKey"] == g2["supKey"] and e["inv"] != g2["inv"] and e["fp"] == g2["fp"]
                    and (g2["minD"] - e["minD"]).days <= S["dupWindowDays"] and g2["minD"] >= e["minD"]):
                dup_of = e; break
        if dup_of:
            g2["dupOf"] = dup_of["inv"]; dup_invoices.append(g2)
        else:
            seen.append(g2)
    dup_line_set = {L["line"] for g2 in dup_invoices for L in g2["lines"]}

    flagged, clean, duplicates = [], [], []
    driftC = phantomC = notReceivedC = duplicateC = downC = billedC = 0
    for L in candidates:
        key = L["supKey"] + "|" + L["itemKey"]
        billedC += L["amountC"]
        if L["line"] in dup_line_set:
            g2 = next(x for x in dup_invoices if any(y["line"] == L["line"] for y in x["lines"]))
            duplicateC += L["amountC"]
            duplicates.append({"line": L["line"], "inv": L["inv"], "dupOf": g2["dupOf"], "supplier": L["sup"],
                               "item": L["item"], "date": L["date"], "qty": L["qty"], "unitC": L["unitC"],
                               "amountC": L["amountC"]})
            continue
        agreed = prices[key]["agreedC"]
        flags, over = [], 0
        diff = L["unitC"] - agreed
        tol = half_up_div(agreed * S["tolTenths"], 1000)
        if diff > tol:
            flags.append("PRICE DRIFT"); over += diff * L["qty"]; driftC += diff * L["qty"]
        elif diff < 0:
            downC += (-diff) * L["qty"]
        if S["requireReceiving"]:
            total_rec = received_total.get(key, 0)
            if total_rec == 0:
                flags.append("NOT RECEIVED"); over += L["amountC"]; notReceivedC += L["amountC"]
            else:
                bal = balance.get(key, 0)
                used = min(bal, L["qty"])
                balance[key] = bal - used
                phantom = L["qty"] - used
                if phantom > 0:
                    flags.append("PHANTOM QTY"); over += phantom * L["unitC"]; phantomC += phantom * L["unitC"]
        rec = {"line": L["line"], "inv": L["inv"], "supplier": L["sup"], "item": L["item"], "date": L["date"],
               "qty": L["qty"], "unitC": L["unitC"], "agreedC": agreed, "amountC": L["amountC"],
               "flags": flags, "overC": over}
        (flagged if flags else clean).append(rec)
    flagged.sort(key=lambda f: (f["supplier"].lower(), f["date"], f["line"]))
    duplicates.sort(key=lambda d2: d2["line"])

    creditC = sum(L["amountC"] for L in credits)
    overchargeC = driftC + phantomC + notReceivedC + duplicateC

    groups = {}

    def bump(sup, field, v):
        k = norm_sup(sup)
        g3 = groups.setdefault(k, {"supplier": sup, "driftC": 0, "phantomC": 0, "notReceivedC": 0,
                                   "duplicateC": 0, "overchargeC": 0, "creditC": 0, "flaggedLines": 0})
        g3[field] += v

    for f in flagged:
        diff = f["unitC"] - f["agreedC"]
        dr = diff * f["qty"] if "PRICE DRIFT" in f["flags"] else 0
        nr = f["amountC"] if "NOT RECEIVED" in f["flags"] else 0
        phq = f["overC"] - dr - nr if "PHANTOM QTY" in f["flags"] else 0
        bump(f["supplier"], "driftC", dr); bump(f["supplier"], "phantomC", phq)
        bump(f["supplier"], "notReceivedC", nr); bump(f["supplier"], "overchargeC", f["overC"])
        bump(f["supplier"], "flaggedLines", 1)
    for d2 in duplicates:
        bump(d2["supplier"], "duplicateC", d2["amountC"]); bump(d2["supplier"], "overchargeC", d2["amountC"])
        bump(d2["supplier"], "flaggedLines", 1)
    for L in credits:
        bump(L["sup"], "creditC", L["amountC"])
    suppliers = sorted(groups.values(), key=lambda g3: (-g3["overchargeC"], g3["supplier"].lower()))
    group_sum = sum(g3["overchargeC"] for g3 in suppliers)

    counts = {"priceRows": price_rows, "receiptRows": receipt_rows, "billLines": bill_lines,
              "priced": len(prices), "refusedPrices": len(refused_prices),
              "receiptsCounted": len(receipts), "receiptsUnmatched": len(unmatched),
              "refusedReceipts": len(refused_receipts),
              "clean": len(clean), "flagged": len(flagged), "review": len(review),
              "credits": len(credits), "outside": len(outside), "duplicateLines": len(duplicates),
              "dupInvoices": len(dup_invoices), "refusedBills": len(refused_bills)}
    lines_tie = counts["billLines"] == (counts["clean"] + counts["flagged"] + counts["review"]
                                        + counts["credits"] + counts["outside"] + counts["duplicateLines"]
                                        + counts["refusedBills"])
    receipts_tie = counts["receiptRows"] == counts["receiptsCounted"] + counts["receiptsUnmatched"] + counts["refusedReceipts"]
    money_tie = overchargeC == driftC + phantomC + notReceivedC + duplicateC and overchargeC == group_sum
    share_bills = pct_tenths(counts["refusedBills"], counts["billLines"]) if counts["billLines"] else 0
    share_receipts = pct_tenths(counts["refusedReceipts"], counts["receiptRows"]) if counts["receiptRows"] else 0
    trusted = lines_tie and receipts_tie and money_tie and share_bills <= 250 and share_receipts <= 250
    banner = ""
    if not trusted:
        if not lines_tie:
            why = "the bill lines do not tie."
        elif not receipts_tie:
            why = "the receiving rows do not tie."
        elif not money_tie:
            why = "the overcharge does not re-total from its causes and suppliers."
        else:
            why = ("too many rows refused (bills %.1f%%, receiving %.1f%%). Fix the export and run it again."
                   % (share_bills / 10, share_receipts / 10))
        banner = "DO NOT TRUST THIS AUDIT — " + why

    return {"settings": {"period": S["period"], "tolTenths": S["tolTenths"],
                         "dupWindowDays": S["dupWindowDays"], "requireReceiving": S["requireReceiving"]},
            "counts": counts,
            "totals": {"overchargeC": overchargeC, "driftC": driftC, "phantomC": phantomC,
                       "notReceivedC": notReceivedC, "duplicateC": duplicateC, "creditC": creditC,
                       "downC": downC, "billedC": billedC, "yearizedC": overchargeC * 12,
                       "groupSumC": group_sum},
            "flagged": flagged, "duplicates": duplicates,
            "clean": [[L2["line"], L2["inv"], L2["amountC"]] for L2 in clean],
            "review": [[L["line"], L["inv"], L["amountC"]] for L in review],
            "credits": [[L["line"], L["inv"], L["amountC"]] for L in credits],
            "outside": [[L["line"], L["inv"], L["amountC"]] for L in outside],
            "suppliers": suppliers,
            "unmatchedReceipts": [[u["line"], u["item"], u["qty"]] for u in unmatched],
            "refusedPrices": [[r["line"], r["name"]] for r in refused_prices],
            "refusedReceipts": [[r["line"], r["name"]] for r in refused_receipts],
            "refusedBills": [[r["line"], r["name"]] for r in refused_bills],
            "notesWithheld": not trusted,
            "recon": {"linesTie": lines_tie, "receiptsTie": receipts_tie, "moneyTie": money_tie,
                      "shareBills_tenths": share_bills, "shareReceipts_tenths": share_receipts,
                      "trusted": trusted, "banner": banner}}


if __name__ == "__main__":
    p = open(sys.argv[1]).read()
    r = open(sys.argv[2]).read()
    b = open(sys.argv[3]).read()
    st = json.loads(sys.argv[4]) if len(sys.argv) > 4 else {"period": "2026-10"}
    print(json.dumps(build(p, r, b, st), indent=1))
